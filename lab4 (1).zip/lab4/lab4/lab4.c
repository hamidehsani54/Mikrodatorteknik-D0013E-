// string "abc", encoded
int codgen(int *seed_addr);
int decode(int *wordarr, char *bytearr, int *seed_addr);
int to_rotating_left(unsigned int seed_addr, int rotateBits); // helping to rotate left

    char plain[132] __attribute__((section(".data")));
    int coded[] __attribute__((section(".data"))) =  
	{
	    // the real encoded data
		0xd93ae2e6,	
		0x01c39fe3,
		0x927a30bf,
		0x5f0a03b1,
		0x3cd20da3,
		0x26c9d97f,
		0xdb695061,
		0x2692e269,
		0x75a9d0a7,
		0x97f3cf36,
		0x4940aac9,
		0xb1f916e0,
		0xb7c7a48b,
		0xecd730d6,
		0x6d4de5b3,
		0xb13eaf04,
		0xc5fbcbeb,
		0x1e939175,
		0x9c24a585,
		0x5191c2f9,
		0x5c0bdefe,
		0x9833ded8,
		0xdc26173a,
		0x47a2f776,
		0xd83c361a,
		0x131edaff,
		0x20546842,
		0xee212f33,
		0x6b875601,
		0x870d51e0,
		0x61501fac,
		0xe5665c86,
		0x917b4329,
		0xcc54de07,
		0xc0dc7c89,
		0x83e9d489,
		0xb89d60ec,
		0xe13983a2,
		0xc94cee4e,
		0xb3210960,
		0x2784f0bd,
		0xadbf9809,
		0xa402c463,
		0x39424f22,
		0xc197a86f,
		0x81845e6d,
		0x980f51a1,
		0xa16731b8,
		0x275b7438,
		0x9429538a,
		0xbf998985,
		0x65e1968a,
		0x11ba2224,
		0xbd023a84,
		0x331dc6f0,
		0x79afadff,
		0xac0f757d,
		0xd9f1d5fc,
		0xae2b68cc,
		0x9dcc4122,
		0xb3e7cc82,
		0x6be24daf,
		0x2a3c41f5,
		0xa9673d37,
		0x34bd70bc,
		0xe1e08dfb,
		0x26f502e2,
		0xcc39d70d,
		0x40797e05,
		0xcef666d7,
		0x3713cfd1,
		0x2d52484f,
		0x75507c95,
		0xb4ae1e14,
		0x102fec46,
		0x8a09619f,
		0x8d52f950,
		0x86b3087b,
		0x49eb8a4b,
		0xc62001dc,
		0x23f7beb7,
		0x6a967d12,
		0x73cb46ee,
		0xbb9417e5,
		0xdcaa2174,
		    0
};
 // string "abc", encoded
int abc[] = { 0xf6705b34, 0xfde6fc03, 0x80b5024, 0};

int main(){
	
	// your seed value here and ignore overflow
	unsigned int seed = 0x11d3004f;  
	unsigned int *seed_addr;
	seed_addr=&seed;
	
	
	decode(coded, plain, &seed);    // call decode 

}

//codgen function
int codgen(int *seed_addr){
	//intialize local variables
	int n;
	unsigned int x, y;
	unsigned int seeds= *seed_addr; // make a cast to unsigine to operate on
	int seeds2= *seed_addr;
	
	//get value of n
	n= seeds & 0x00007C00;
	n=n>>0xa;
		
	while(n>=0){
		x= to_rotating_left(seeds, 2); //rotate left with 2 bites
		y= seeds2 >> 10; // shift right with 10 bites
		seeds = x - y;  // seed gets a new value
		seeds2=seeds;	
		n-=1;
		*seed_addr = seeds;
		
	}
	
	return (seeds ^ 0x7d9bb012); // return seeds XOR 0x7d9bb012.
	

}
int decode(int *wordarr, char *bytearr, int *seed_addr)
{
	unsigned int m, r, x, y;

	x = ~codgen(seed_addr); // x gets new value of one's complement(seed_addr)

	if (*wordarr == 0)
	{
		*bytearr = 0; // value pointed by bytearr equal to 0 
		r = x;		
	}
	else
	{
		y = decode(wordarr + 1, bytearr + 1, seed_addr); //call the decode with next address index in both wordarr and bytearr 
		m = (x - y) - *wordarr; // wardarrs value 
		
		*bytearr = m >> 0x13; //gets throught <26:19> and then save the value pointed by bytearr.  

		r = (~codgen(seed_addr)) + 1; // r gets a new value by twosComplement of codgen.
		r = r + x + y + m + 5;
	}
	return r;

}

int to_rotating_left(unsigned int seed_addr, int rotatebits)
{
	int  seed_rotate_left= seed_addr >> (32 - rotatebits); // dummy variable for shifting 
	int n = seed_addr << rotatebits; // rotate seed_addr by x bits to the left 
	return(n | seed_rotate_left);  // n OR seed_rotate_left 
}



